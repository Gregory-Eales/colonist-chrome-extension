// Things are happening
var elem = document.getElementById("in-game-ad-right");
elem.remove();
var elem = document.getElementById("in-game-ad-left");
elem.remove();

